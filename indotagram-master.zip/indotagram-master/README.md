# indotagram
Get Cookie Instgram Via Termux Android

$ git clone https://github.com/indogram/indotagram.git

$ php indotagram/login.php

